from distutils.core import setup

setup(
	name="maptools",
	author_email = "privezentsev@gmail.com",
	packages = ["maptools"],
	scripts = ["addminimap","splitmap"]    	
    
)
