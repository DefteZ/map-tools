from distutils.core import setup

setup(

	name="maptools",
	version ="0.0.1",
	author_email = "privezentsev@gmail.com",
	packages = ["maptools"],
	scripts = ["addminimap","splitmap"]    	
    
)

