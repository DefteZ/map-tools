from distutils.core import setup

setup(
	name="maptools",
	version ="001",
	author_email = "privezentsev@gmail.com",
	packages = ["maptools"],
	scripts = ["addminimap","splitmap"]    	
    
)
